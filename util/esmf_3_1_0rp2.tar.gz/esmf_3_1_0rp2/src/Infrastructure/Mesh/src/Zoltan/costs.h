/*****************************************************************************
 * CVS File Information :
 *    $RCSfile: costs.h,v $
 *    $Author: dneckels $
 *    $Date: 2007/08/08 22:43:47 $
 *    Revision: 1.8 $
 ****************************************************************************/

#ifndef __COSTS_H
#define __COSTS_H

#include "costs_const.h"

#ifdef __cplusplus
/* if C++, define the rest of this header file as extern C */
extern "C" {
#endif


#ifdef __cplusplus
} /* closing bracket for extern "C" */
#endif

#endif
