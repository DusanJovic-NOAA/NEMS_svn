// $Id: ESMC_InternArrayDataMap.C,v 1.1 2006/03/24 16:33:28 theurich Exp $
//
//-------------------------------------------------------------------------
//BOP
//
// !CLASS: ESMC_ArrayDataMap

// !PUBLIC MEMBER FUNCTIONS:

// TODO: remove this once this file contains real code.  otherwise ranlib
// moans about no visible symbols in the .o file.  sigh.
static int fred;

// !INTERFACE:
//  void ESMC_ArrayDataMapValidate(ESMC_ArrayDataMap *datamap, int *rc);
//   // Routine to validate the internal state of an datamap object.
//   // !REQUIREMENTS:  FLD4.1
//   //
//   //
// !INTERFACE:
//  void ESMC_ArrayDataMapPrint(ESMC_ArrayDataMap *datamap, char *options, int *rc);
//   // Routine to print information about an datamap object.
//   // !REQUIREMENTS:
//   //
//   //
//EOP
//

